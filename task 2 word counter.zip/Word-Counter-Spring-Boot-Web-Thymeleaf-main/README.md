# Word Counter Spring Boot Web Thymeleaf
This repository contains Spring Boot Web Application using Thymeleaf for calculating number of words from raw input text.
